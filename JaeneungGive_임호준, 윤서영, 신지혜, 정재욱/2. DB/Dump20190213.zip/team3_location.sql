-- MySQL dump 10.13  Distrib 5.5.15, for Win64 (x86)
--
-- Host: 192.168.0.21    Database: team3
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `lo1` varchar(10) DEFAULT NULL,
  `lo2` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES ('서울특별시','종로구'),('서울특별시','중구'),('서울특별시','용산구'),('서울특별시','성동구'),('서울특별시','광진구'),('서울특별시','동대문구'),('서울특별시','중랑구'),('서울특별시','성북구'),('서울특별시','강북구'),('서울특별시','도봉구'),('서울특별시','노원구'),('서울특별시','은평구'),('서울특별시','서대문구'),('서울특별시','마포구'),('서울특별시','양천구'),('서울특별시','강서구'),('서울특별시','구로구'),('서울특별시','금천구'),('서울특별시','영등포구'),('서울특별시','동작구'),('서울특별시','관악구'),('서울특별시','서초구'),('서울특별시','강남구'),('서울특별시','송파구'),('서울특별시','강동구'),('부산광역시','중구'),('부산광역시','서구'),('부산광역시','동구'),('부산광역시','영도구'),('부산광역시','부산진구'),('부산광역시','동래구'),('부산광역시','남구'),('부산광역시','북구'),('부산광역시','강서구'),('부산광역시','해운대구'),('부산광역시','사하구'),('부산광역시','금정구'),('부산광역시','연제구'),('부산광역시','수영구'),('부산광역시','사상구'),('부산광역시','기장군'),('경기도','수원시 장안구'),('경기도','수원시 권선구'),('경기도','수원시 팔달구'),('경기도','수원시 영통구'),('경기도','성남시 수정구'),('경기도','성남시 중원구'),('경기도','성남시 분당구'),('경기도','안양시 만안구'),('경기도','안양시 동안구'),('경기도','안산시 상록구'),('경기도','안산시 단원구'),('경기도','용인시 처인구'),('경기도','용인시 기흥구'),('경기도','용인시 수지구'),('경기도','광명시'),('경기도','평택시'),('경기도','과천시'),('경기도','오산시'),('경기도','시흥시'),('경기도','군포시'),('경기도','의왕시'),('경기도','하남시'),('경기도','이천시'),('경기도','안성시'),('경기도','김포시'),('경기도','화성시'),('경기도','광주시'),('경기도','여주시'),('경기도','부천시'),('경기도','양평군'),('경기도','고양시 덕양구'),('경기도','고양시 일산동구'),('경기도','고양시 일산서구'),('경기도','의정부시'),('경기도','동두천시'),('경기도','구리시'),('경기도','남양주시'),('경기도','파주시'),('경기도','양주시'),('경기도','포천시'),('경기도','연천군'),('경기도','가평군');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-13  9:44:39

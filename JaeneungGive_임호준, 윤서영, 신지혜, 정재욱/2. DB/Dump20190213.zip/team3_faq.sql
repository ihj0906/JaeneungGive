-- MySQL dump 10.13  Distrib 5.5.15, for Win64 (x86)
--
-- Host: 192.168.0.21    Database: team3
-- ------------------------------------------------------
-- Server version	5.5.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faq`
--

DROP TABLE IF EXISTS `faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq`
--

LOCK TABLES `faq` WRITE;
/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` VALUES (1,'재능기부를 받기 전에 작성자 분께 궁금한 것이 있어요.','쪽지보내기로 재능기부 받기 신청하셨다면 회원님의 프로필이 작성자에게 전송됩니다. 이제 가끔 재능기부에 들려서 답장이 왔는지 확인해주세요. 쪽지로 간단한 협의를 마치시고 레슨을 시작하시면 됩니다. 프로필에 정보가 많을수록 연락올 확률이 높으니 프로필을 자세하게 작성해주시는 것이 좋습니다.'),(2,'재능기부 글을 작성했는데 이제 어떻게 해야 하나요?','새로운 재능기부 글을 개설하셨다면 일반적으로 2주안에 1~2명에서 많게는 5~8명까지 쪽지신청이 접수되며 받은쪽지함에서 확인해보실수 있습니다. 신청하신 회원님들의 프로필을 확인해 보시고 그중에 원하시는 분과 쪽지로 내용과 장소를 협의하신후 재능기부를 시작하시면 됩니다.'),(3,'배우고 싶은 건 많은데 가르쳐줄게 없으면 어떻게 하나요?','한국인이라면 기본적으로 한국어를 가르쳐 주실수 있습니다. 그리고 운전을 하신다면 운전을 가르쳐 주실수도 있고 요리도 가능합니다. 또는 직업으로 하고 계신 일을 가르쳐 주셔도 됩니다. 의외로 많은 분들이 여러분의 레슨을 기다리고 있습니다. 한번 시작해보세요!'),(4,'연락을 주고 받은 끝에 재능교환을 시작하기로 했습니다. 이제 어떻게 해야 하나요?','재능교환 성공을 축하드립니다^^ 재능교환을 시작하셨다면 더이상 재능교환 신청을 받으실 필요가 없으시니 해당 작성글로 가셔서 신청마감하기를 클릭하셔서 재능교환 신청을 마감해주세요.'),(5,'쪽지를 보내도 답장이 잘 오지 않습니다.','쪽지를 보내도 답변이 오지 않으신다면 프로필을 좀더 자세하게 채워주시는 것이 좋습니다. 특히 12주간의 커리큘럼을 상세하게 써주신다면 좀더 연락이 올 확률이 높아집니다.');
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-13  9:44:38
